<?php

include_once ("conexao.php");

$nome = $_POST['nome'];
$email = $_POST['email'];
$profissao = $_POST['profissao'];

$sql = "INSERT INTO Usuarios (nome, email, profissao) VALUE ('$nome', '$email', '$profissao')";
$salvar = mysqli_query($conexao,$sql);
mysqli_close($conexao);

?>